#' Example data
#'
#' The data set included in this package has been simulated in order not to disclose the proprietary data
#' owned by a third party. It has been designed in order to demonstrate the use of all R-functions in the
#' package.
#'
#' @format A data frame with 350 synthetically generated observations.
#'  \describe{
#'    \item{ObesityClass}{Obesity status of a patient. The different classes were defined as "Normal weight" (BMI<25), "Overweight" (25<BMI<30) and "Obese" (BMI>30).}
#'    \item{Age}{The age of the patient at the time of the blood draw.}
#'    \item{BMI}{The patient's BMI}
#'    \item{met_001}{Circulating plasma metabolite levels of met_001}
#'    \item{met_002}{Circulating plasma metabolite levels of met_002}
#'    \item{met_110}{Circulating plasma metabolite levels of met_110}
#'    \item{met_coll}{Circulating plasma metabolite levels of met_coll, generated to have collinearity with met_001 and met_002}
#'  }
#'
#' @source {https://github.com/jkmoerma/BMI-simulated-data}
#'
#' @examples
#' data(df)
#'
"df"
